# Truly Night Eye 1.0.4 - Jiaye AIO

An adjustable Night Eye addon for Skyrim with its own in-game configuration menu.

This separate edition targets Jiaye AIO on Steam SE and AE. Its mod version is **1.0.4**. It includes guarded menu routing to the engine's redirected framebuffer UI target, retaining the backbuffer fallback and Present order. The shared routing correction accepts a validated UI target without requiring a separate scene texture pointer, and excludes the actual swapchain backbuffer from redirected target selection. Other visual effects and shader assets are retained, and older settings files remain supported.

The startup log identifies the Jiaye edition and version after SKSE initialization. Menu diagnostics record the selected target route. In-game testing with this exact AIO, including the HDR menu path and SE 1.5.97, remains pending.

## Effects

- Visibility controls for exposure, shadow gamma, shadow lift and transition speed.
- Tint colour and strength, glow, vignette and grain.
- Adjustable eyeshine strength and colour for human and creature eyes.
- Anaglyph colour split with editable channel colours, separation and desaturation.
- Simulated infrared vision and Predator colours: red enemies, green allies and grey neutral actors by default.
- Editable custom VFX with an adjustable strength.

## Requirements

- Windows 10/11 x64 and Skyrim Special Edition Steam **1.5.97**, **1.6.1130**, **1.6.1170**, or **1.7.104**. The paid Anniversary Upgrade is not required.
- [SKSE64](https://skse.silverlock.org/) **2.0.20** for Steam 1.5.97, or the matching SKSE64 build for the other exact game versions.
- [Address Library for SKSE Plugins](https://www.nexusmods.com/skyrimspecialedition/mods/32444), containing the matching file below.
- [Microsoft Visual C++ v14 Redistributable x64](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist).
- The exact **Jiaye AIO** package `CommunityShaders_AIO-2026-10-03T06-46Z.7z`, with its own requirements installed. Its Community Shaders core reports **1.9.0**.

| Steam Skyrim runtime | Required Address Library file |
| --- | --- |
| 1.5.97 | `version-1-5-97-0.bin` |
| 1.6.1130 | `versionlib-1-6-1130-0.bin` |
| 1.6.1170 | `versionlib-1-6-1170-0.bin` |
| 1.7.104 | `versionlib-1-7-104-0.bin`, format 5 |

This edition accepts only that AIO's `SKSE/Plugins/CommunityShaders.dll`, SHA256 `ae89f2cd4df10674de505555fc0af698a19c819232ada6a817ef9acd0b568ca6`. GOG, Skyrim VR, other Steam runtimes, and other graphics-core builds are unsupported. Effects 11 and SkyUI are not required.

For HDR, use Jiaye's Post Processing tonemapper, tonemap owner 1. Vanilla HDR without Linear Lighting is unsupported.

## Installation and controls

Install the addon ZIP as a separate mod in your mod manager and enable it alongside the exact Jiaye AIO. Disable other Truly Night Eye versions, an older Night Eye Native integration, and other Night Eye shader overrides, then launch Skyrim through SKSE. The addon ZIP contains only Night Eye files and notices; it includes no host binaries or host shaders.

Activate a Night Eye ability, such as the Khajiit racial power. Press **F10** to open the Truly Night Eye window. Adjust the effect in its tabs and click **Save** to retain your settings. The menu shortcut can be changed in the Menu tab.

To enable eyeshine, increase **Eyeshine Strength** above zero. Actor Vision, Anaglyph and Custom VFX are optional. Custom VFX can be edited in `Data/Shaders/NightEye/CustomVFX.hlsli`; click **Reload Night Eye Shader** after editing.

The menu automatically scales text and controls for the display resolution: 1080p retains the original size, 1440p uses about 1.33x and 4K uses 2x. **Menu Scale** in the Menu tab adjusts that size from 0.75x to 2x. **Remove Night Eye Blur** in Visibility disables blur and radial blur in the standard Night Eye intro, active and ending modifiers. Reactivate Night Eye after changing it. Other modifier settings and the separate Glow control are preserved; custom spells using different modifiers are outside this toggle. Both new settings are saved with the existing version 1 settings document, and older documents retain defaults for missing fields. Live verification of these controls remains pending.

Eyeshine supports identifiable eye meshes and included creature masks, including mammoths, giants and mudcrabs. Some custom creature meshes need an additional mask or eye identification. Version 1.0.4 does not provide automatic eyeshine for every creature mod.

The addon also observes the standard Night Eye intro and active visual modifiers. This recognizes scripted abilities applying those presets, including Arcane Accessories' **Orum's Aquatic Escape**, alongside the existing magic-effect detector. It does not modify spell activation, scripts, costs, duration, invisibility or waterbreathing. The ending modifier alone does not activate the addon. Scripts using unrelated custom presets or shader-only changes still need separate compatibility support. Spell record/script inspection and native detector checks verify the compatibility path; in-game confirmation remains pending.

## Source and licence

Truly Night Eye is licensed under **GPL-3.0-or-later**, with the modding and linking permissions in [EXCEPTIONS.md](EXCEPTIONS.md). The full licence is in [LICENSE](LICENSE), and retained third-party notices are in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

The matching **Truly Night Eye 1.0.4 - Jiaye AIO Source.zip** is supplied alongside this addon edition, including editable eye masks and corresponding dependency sources. This Jiaye AIO edition has not been published to the original project's GitHub repository. See [BUILDING.md](BUILDING.md) for build instructions and [dependency-sources](dependency-sources) for dependency source archives and their recorded versions.
