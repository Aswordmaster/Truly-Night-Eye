#if !defined(MULTBLEND) && !defined(MULTBLEND_DECAL)
	[branch] if (NightEyeStandalone::Eye.w > 0.0 && NightEyeStandalone::Flags.x != 0 && NightEyeStandalone::IsWorld())
	{
		float nightEyeShape = saturate(Color::RGBToLuminance(baseTexColor.xyz)) * saturate(alpha);
		float3 nightEyeColor = Color::LinearSRGBToWorking(NightEyeStandalone::Eye.xyz);
		lightColor = NightEyeStandalone::EffectFromLinear(NightEyeStandalone::EffectToLinear(lightColor) +
			nightEyeColor * (NightEyeStandalone::Eye.w * nightEyeShape));
	}
#endif
